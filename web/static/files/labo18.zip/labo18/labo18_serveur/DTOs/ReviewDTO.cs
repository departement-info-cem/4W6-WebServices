﻿namespace serveur16.DTOs
{
    public class ReviewDTO
    {
        public string Text { get; set; } = null!;
        public string Game { get; set; } = null!;
    }
}
