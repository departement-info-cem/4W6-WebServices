export class Profile{
    constructor(public name : string, public age : string, public money : number){}
  }
  