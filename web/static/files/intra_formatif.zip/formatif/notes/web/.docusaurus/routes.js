import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/4W6-WebServices/__docusaurus/debug',
    component: ComponentCreator('/4W6-WebServices/__docusaurus/debug', 'd56'),
    exact: true
  },
  {
    path: '/4W6-WebServices/__docusaurus/debug/config',
    component: ComponentCreator('/4W6-WebServices/__docusaurus/debug/config', '14d'),
    exact: true
  },
  {
    path: '/4W6-WebServices/__docusaurus/debug/content',
    component: ComponentCreator('/4W6-WebServices/__docusaurus/debug/content', '740'),
    exact: true
  },
  {
    path: '/4W6-WebServices/__docusaurus/debug/globalData',
    component: ComponentCreator('/4W6-WebServices/__docusaurus/debug/globalData', '4f3'),
    exact: true
  },
  {
    path: '/4W6-WebServices/__docusaurus/debug/metadata',
    component: ComponentCreator('/4W6-WebServices/__docusaurus/debug/metadata', '5e8'),
    exact: true
  },
  {
    path: '/4W6-WebServices/__docusaurus/debug/registry',
    component: ComponentCreator('/4W6-WebServices/__docusaurus/debug/registry', '163'),
    exact: true
  },
  {
    path: '/4W6-WebServices/__docusaurus/debug/routes',
    component: ComponentCreator('/4W6-WebServices/__docusaurus/debug/routes', '4e7'),
    exact: true
  },
  {
    path: '/4W6-WebServices/',
    component: ComponentCreator('/4W6-WebServices/', '030'),
    routes: [
      {
        path: '/4W6-WebServices/',
        component: ComponentCreator('/4W6-WebServices/', '491'),
        routes: [
          {
            path: '/4W6-WebServices/',
            component: ComponentCreator('/4W6-WebServices/', '270'),
            routes: [
              {
                path: '/4W6-WebServices/cours/rencontre1.1',
                component: ComponentCreator('/4W6-WebServices/cours/rencontre1.1', '8c9'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/4W6-WebServices/cours/rencontre1.2',
                component: ComponentCreator('/4W6-WebServices/cours/rencontre1.2', '8bf'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/4W6-WebServices/cours/rencontre2.1',
                component: ComponentCreator('/4W6-WebServices/cours/rencontre2.1', '1c6'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/4W6-WebServices/cours/rencontre2.2',
                component: ComponentCreator('/4W6-WebServices/cours/rencontre2.2', '8e9'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/4W6-WebServices/cours/rencontre3.1',
                component: ComponentCreator('/4W6-WebServices/cours/rencontre3.1', '4b2'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/4W6-WebServices/cours/rencontre3.2',
                component: ComponentCreator('/4W6-WebServices/cours/rencontre3.2', '415'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/4W6-WebServices/cours/rencontre4.1',
                component: ComponentCreator('/4W6-WebServices/cours/rencontre4.1', '46b'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/4W6-WebServices/cours/rencontre4.2',
                component: ComponentCreator('/4W6-WebServices/cours/rencontre4.2', '81c'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/4W6-WebServices/',
                component: ComponentCreator('/4W6-WebServices/', '866'),
                exact: true
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
