import { Component, OnInit } from '@angular/core';
import { Character } from '../models/character';
import { CommonModule } from '@angular/common';
import { TranslateModule, TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-favorites',
  standalone: true,
  imports: [CommonModule, TranslateModule],
  templateUrl: './favorites.component.html',
  styleUrl: './favorites.component.css'
})
export class FavoritesComponent implements OnInit{

  characters : Character[] = [];

  // N'AJOUTEZ PAS la ligne avec .setFallbackLang() ! Ce projet est dans une 
  // ancienne version d'Angular et cette fonction n'existait pas avant.

  constructor(){}

  ngOnInit(){

  }

  emptyFavs(){

  }

}
