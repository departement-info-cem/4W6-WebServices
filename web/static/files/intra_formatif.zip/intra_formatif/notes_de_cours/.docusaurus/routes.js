import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/4W6-WebServices/__docusaurus/debug',
    component: ComponentCreator('/4W6-WebServices/__docusaurus/debug', 'd56'),
    exact: true
  },
  {
    path: '/4W6-WebServices/__docusaurus/debug/config',
    component: ComponentCreator('/4W6-WebServices/__docusaurus/debug/config', '14d'),
    exact: true
  },
  {
    path: '/4W6-WebServices/__docusaurus/debug/content',
    component: ComponentCreator('/4W6-WebServices/__docusaurus/debug/content', '740'),
    exact: true
  },
  {
    path: '/4W6-WebServices/__docusaurus/debug/globalData',
    component: ComponentCreator('/4W6-WebServices/__docusaurus/debug/globalData', '4f3'),
    exact: true
  },
  {
    path: '/4W6-WebServices/__docusaurus/debug/metadata',
    component: ComponentCreator('/4W6-WebServices/__docusaurus/debug/metadata', '5e8'),
    exact: true
  },
  {
    path: '/4W6-WebServices/__docusaurus/debug/registry',
    component: ComponentCreator('/4W6-WebServices/__docusaurus/debug/registry', '163'),
    exact: true
  },
  {
    path: '/4W6-WebServices/__docusaurus/debug/routes',
    component: ComponentCreator('/4W6-WebServices/__docusaurus/debug/routes', '4e7'),
    exact: true
  },
  {
    path: '/4W6-WebServices/',
    component: ComponentCreator('/4W6-WebServices/', '7bb'),
    routes: [
      {
        path: '/4W6-WebServices/',
        component: ComponentCreator('/4W6-WebServices/', 'dd6'),
        routes: [
          {
            path: '/4W6-WebServices/',
            component: ComponentCreator('/4W6-WebServices/', '9a4'),
            routes: [
              {
                path: '/4W6-WebServices/notes/rencontre1.1',
                component: ComponentCreator('/4W6-WebServices/notes/rencontre1.1', 'e18'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/4W6-WebServices/notes/rencontre1.2',
                component: ComponentCreator('/4W6-WebServices/notes/rencontre1.2', '3e7'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/4W6-WebServices/notes/rencontre2.1',
                component: ComponentCreator('/4W6-WebServices/notes/rencontre2.1', 'f13'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/4W6-WebServices/notes/rencontre3.1',
                component: ComponentCreator('/4W6-WebServices/notes/rencontre3.1', '8b6'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/4W6-WebServices/notes/rencontre3.2',
                component: ComponentCreator('/4W6-WebServices/notes/rencontre3.2', 'f2d'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/4W6-WebServices/notes/rencontre4.1',
                component: ComponentCreator('/4W6-WebServices/notes/rencontre4.1', '76b'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/4W6-WebServices/notes/rencontre4.2',
                component: ComponentCreator('/4W6-WebServices/notes/rencontre4.2', '0bc'),
                exact: true,
                sidebar: "docs"
              },
              {
                path: '/4W6-WebServices/',
                component: ComponentCreator('/4W6-WebServices/', '866'),
                exact: true
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
