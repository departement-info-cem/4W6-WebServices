export default [
  require("D:\\cegep_cours\\prog web services\\intras\\h25\\notes_de_cours\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("D:\\cegep_cours\\prog web services\\intras\\h25\\notes_de_cours\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("D:\\cegep_cours\\prog web services\\intras\\h25\\notes_de_cours\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("D:\\cegep_cours\\prog web services\\intras\\h25\\notes_de_cours\\src\\css\\custom.css"),
];
