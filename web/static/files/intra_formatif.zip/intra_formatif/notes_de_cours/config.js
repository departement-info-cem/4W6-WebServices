const config = {
    nom: "4204W6 - Programmation Web orientée services",
    description: "Site de référence du cours Programmation Web orientée services",
    nomUrl: "4W6-WebServices"
}

module.exports = config;