import { CommonModule } from '@angular/common';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { PictureService } from './services/picture.service';



@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit{

  pictureIds : number[] = []; // Pas besoin de model pour les pictures ... les ids suffisent ...

  constructor(public pictureService : PictureService){}

  async ngOnInit() {
    //this.pictureIds = await ...;
  }

  async updateDisplay(){
    //this.pictureIds = await ...;
  }

  async postPicture(){

    let formData = new FormData();
    
    await this.pictureService.postPicture(formData);
    
  }

  async deletePicture(id : number){

    await this.pictureService.deletePicture(id);
    this.pictureIds.splice(this.pictureIds.indexOf(id), 1);

  }

}
