import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { lastValueFrom } from 'rxjs';

const domain = "https://localhost:█BRUH█/";

@Injectable({
  providedIn: 'root'
})
export class PictureService {

  constructor(public http : HttpClient) { }

  async postPicture(formData : any){
    


  }

  async getPictureIds() : Promise<number[]>{

    // À modifier
    return [];

  }

  async deletePicture(id : number){



  }

}
