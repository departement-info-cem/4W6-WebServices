﻿namespace semaine11_serveur.Models
{
    public class Picture
    {
        // salut ça va ? ta session se passe bien ? tu prends soin de toi ? 
    }
}
