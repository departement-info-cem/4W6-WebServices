﻿namespace serveur21.DTOs
{
    public class ReviewDTO
    {
        public string Text { get; set; } = null!;
    }
}
