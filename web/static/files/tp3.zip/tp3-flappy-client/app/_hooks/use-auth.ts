
const domain = "https://localhost:████/";

export function useAuth() {

    async function register(username: string, password: string, passwordConfirm: string) {



    }

    async function login(username: string, password: string) {



    }

    return { register, login };

}