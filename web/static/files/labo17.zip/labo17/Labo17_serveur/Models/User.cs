﻿using Microsoft.AspNetCore.Identity;

namespace Labo17_serveur.Models
{
    public class User : IdentityUser
    {

    }
}
