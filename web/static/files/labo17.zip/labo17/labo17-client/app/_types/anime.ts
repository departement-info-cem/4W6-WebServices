
export class Anime{

    constructor(
        public id : number,
        public name : string,
        public genres : string[],
        public imageUrl ?: string
    ){}

}