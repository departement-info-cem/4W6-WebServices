﻿namespace semaine11_serveur.Models
{
    public class Picture
    {
        public int Id { get; set; }
    }
}
