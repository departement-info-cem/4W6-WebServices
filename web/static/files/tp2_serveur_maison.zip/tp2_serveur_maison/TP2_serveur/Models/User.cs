﻿using Microsoft.AspNetCore.Identity;

namespace TP2_serveur.Models
{
    public class User : IdentityUser
    {
    }
}
