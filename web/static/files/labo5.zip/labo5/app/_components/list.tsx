
export default function List() {

    const characters : string[] = ["bebe","butters","clyde","craig","eric","kenny","kyle","nichole","stan","tolkien","wendy"];

    return (
        <div>
            <h3>Liste de personnages</h3>

            <div className="characters">

                {/* Intégrer le composant card ici ... plusieurs fois ! */}

            </div>
        </div>

    );

} 