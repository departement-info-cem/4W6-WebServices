export class Digimon{

    constructor(public id : number, public name : string, public imageUrl : string, public types : string[]){}

}