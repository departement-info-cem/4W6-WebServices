import { Routes } from '@angular/router';
import { Plumbing } from './plumbing/plumbing';
import { Swift } from './swift/swift';
import { YoutubeSearch } from './youtube-search/youtube-search';

export const routes: Routes = [
    {path:"", redirectTo:"/youtube", pathMatch:"full"},
    {path:"youtube", component:YoutubeSearch},
    {path:"swift", component:Swift},
    {path:"plumbing", component:Plumbing}
];
