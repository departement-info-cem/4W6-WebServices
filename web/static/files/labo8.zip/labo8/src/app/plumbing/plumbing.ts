import { Component } from '@angular/core';

@Component({
  selector: 'app-plumbing',
  imports: [],
  templateUrl: './plumbing.html',
  styleUrl: './plumbing.css'
})
export class Plumbing {

  maDate : string = "2025-11-15";

  constructor() { }

}
