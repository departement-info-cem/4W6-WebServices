import { Component } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { GoogleService } from '../services/google-service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

// Domaine pour YouTube
const youtubeURL = "https://www.youtube.com/embed/";

@Component({
  selector: 'app-youtube-search',
  imports: [FormsModule, CommonModule],
  templateUrl: './youtube-search.html',
  styleUrl: './youtube-search.css'
})
export class YoutubeSearch {

  videoSearchText : string = "";
  videoId : string = "";
  videoUrl ?: SafeResourceUrl;

  constructor(public google : GoogleService, public sanitizer : DomSanitizer) { }

  ngOnInit() {
  }

  searchVideo():void{
    this.videoId = this.google.searchVideoId(this.videoSearchText); // Obtenir l'id d'une vidéo
    
    // Remplissez la variable this.videoUrl avec l'URL de la vidéo à afficher MAIS n'oubliez pas de "sanitize" l'URL.
    // Il vous suffira de concaténer la constante youtubeURL avec this.videoId puis de sanitizer.
    
	// this.videoUrl =

    // (La vidéo sera automatiquement affichée une fois cette variable remplie)
  }

}
