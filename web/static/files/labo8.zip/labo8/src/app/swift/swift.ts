import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { GoogleMapsModule } from '@angular/google-maps';

@Component({
  selector: 'app-swift',
  imports: [GoogleMapsModule, FormsModule],
  templateUrl: './swift.html',
  styleUrl: './swift.css'
})
export class Swift {

  inputLat : number = 0;
  inputLng : number = 0;

  center : google.maps.LatLngLiteral = {lat: 42, lng: -4};
  zoom : number = 2;

  // Ajoutez une variable de classe qui servira de tableau de marqueurs

  constructor() { }

  ngOnInit() {
  }

  addMarker() : void {
    // Ajoutez un marqueur dans votre tableau de marqueurs en vous servant des données this.inputLat et this.inputLng !
  }

  clearMarkers() : void {
    // Videz le tableau de marqueurs ! (= [])
  }

}
